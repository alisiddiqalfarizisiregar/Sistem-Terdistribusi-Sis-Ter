<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Tipe extends Model
{
    /*use HasFactory;
    public $primaryKey='id';
    protected $table="tipes";
    protected $fillable = [
        'nama'
    ];
    public function products(){
        return $this->hasMany(Products::class,'id','tipe_id');
    }*/
}
